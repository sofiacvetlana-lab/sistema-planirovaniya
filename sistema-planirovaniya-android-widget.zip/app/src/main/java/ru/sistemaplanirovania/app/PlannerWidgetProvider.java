package ru.sistemaplanirovania.app;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.widget.RemoteViews;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class PlannerWidgetProvider extends AppWidgetProvider {

    private static final String PREFS = "planner_widget";
    private static final String KEY_TASKS = "tasks";

    private static final String DEMO_TASKS =
            "Получить зарплату|18:00|red\n" +
            "Забрать ноутбук с ремонта|17:00|green\n" +
            "Помыть пол до прихода жены|20:00|blue";

    @Override
    public void onUpdate(Context context, AppWidgetManager manager, int[] ids) {
        for (int id : ids) {
            updateWidget(context, manager, id);
        }
    }

    @Override
    public void onEnabled(Context context) {
        super.onEnabled(context);
        updateAll(context);
    }

    public static void updateAll(Context context) {
        AppWidgetManager manager = AppWidgetManager.getInstance(context);
        ComponentName component = new ComponentName(context, PlannerWidgetProvider.class);
        int[] ids = manager.getAppWidgetIds(component);
        for (int id : ids) {
            updateWidget(context, manager, id);
        }
    }

    private static void updateWidget(Context context, AppWidgetManager manager, int id) {
        RemoteViews views = new RemoteViews(context.getPackageName(), R.layout.widget_planner);

        String date = new SimpleDateFormat("d MMMM", new Locale("ru", "RU"))
                .format(new Date());

        views.setTextViewText(R.id.widget_date, date);

        String tasks = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .getString(KEY_TASKS, DEMO_TASKS);

        String[] rows = tasks.split("\n", -1);
        setRow(views, 0, rows);
        setRow(views, 1, rows);
        setRow(views, 2, rows);

        Intent openApp = new Intent(context, MainActivity.class);
        PendingIntent openPending = PendingIntent.getActivity(
                context,
                100,
                openApp,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        views.setOnClickPendingIntent(R.id.widget_root, openPending);
        views.setOnClickPendingIntent(R.id.widget_add, openPending);

        manager.updateAppWidget(id, views);
    }

    private static void setRow(RemoteViews views, int index, String[] rows) {
        int textId;
        int timeId;
        int dotId;

        if (index == 0) {
            textId = R.id.task1_text;
            timeId = R.id.task1_time;
            dotId = R.id.task1_dot;
        } else if (index == 1) {
            textId = R.id.task2_text;
            timeId = R.id.task2_time;
            dotId = R.id.task2_dot;
        } else {
            textId = R.id.task3_text;
            timeId = R.id.task3_time;
            dotId = R.id.task3_dot;
        }

        if (index >= rows.length || rows[index].trim().isEmpty()) {
            views.setTextViewText(textId, "");
            views.setTextViewText(timeId, "");
            return;
        }

        String[] parts = rows[index].split("\|");
        String title = parts.length > 0 ? parts[0] : "";
        String time = parts.length > 1 ? parts[1] : "";
        String color = parts.length > 2 ? parts[2] : "green";

        views.setTextViewText(textId, title);
        views.setTextViewText(timeId, time);

        int dotColor = Color.rgb(95, 175, 138);
        if ("red".equals(color)) {
            dotColor = Color.rgb(238, 83, 80);
        } else if ("blue".equals(color)) {
            dotColor = Color.rgb(100, 135, 175);
        }

        views.setInt(dotId, "setColorFilter", dotColor);
    }
}

package ru.sistemaplanirovania.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {

    // ВАЖНО: сюда позже поставим точный адрес твоего GitHub Pages.
    // Пример: https://username.github.io/sistema-planirovaniya/
    public static final String WEB_APP_URL =
            "https://sofiacvetlana-lab.github.io/sistema-planirovaniya/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        WebView webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244, 247, 245));

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());

        webView.loadUrl(WEB_APP_URL);
        setContentView(webView);
    }

    @Override
    public void onBackPressed() {
        View view = findViewById(android.R.id.content);
        if (view instanceof LinearLayout) {
            // Ничего специального не делаем.
        }
        super.onBackPressed();
    }
}
